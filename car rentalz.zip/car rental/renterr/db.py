import pymongo

# 1. Connect to MongoDB
client = pymongo.MongoClient("mongodb://localhost:27017/")

# 2. Access a Database
db = client["mydatabase"]

# 3. Access a Collection
collection = db["mycollection"]

# 4. Insert a Document
data = {"name": "John", "age": 30, "city": "New York"}
collection.insert_one(data)

# 5. Find Documents
query = {"city": "New York"}
results = collection.find(query)
for result in results:
    print(result)