<?php
$hostName = "localhost";
$dbUser = "root";
$dbPassword = "";
$dbName = "login";
$conn = mysqli_connect($hostName, $dbUser, $dbPassword,$dbName);
if (!$conn){
    die("something went wrong;");
}  

if (isset($_POST["submit"])) {
    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $passwordRepeat = $_POST["repeat_password"];

    // Validation
    $errors = array();
    if (empty($username) || empty($email) || empty($password) || empty($passwordRepeat)) {
        $errors[] = "All fields are required.";
    } elseif ($password !== $passwordRepeat) {
        $errors[] = "Passwords do not match.";
    } else {
        // Password hashing
    

        // require_once "database.php"

        // Check if user exists
        $sql = "SELECT * FROM login4 WHERE email=?";
        $stmt = mysqli_stmt_init($conn);
        if (mysqli_stmt_prepare($stmt, $sql)) {
            mysqli_stmt_bind_param($stmt, "s", $email);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);
            if (mysqli_stmt_num_rows($stmt) > 0) {
                $errors[] = "User already exists with this email.";
            }
        } else {
            $errors[] = "Database error.";
        }

        // If no errors, insert new user
        if (empty($errors)) {
            $sql = "INSERT INTO login4 (username, email, password) VALUES (?, ?, ?)";
            $stmt = mysqli_stmt_init($conn);
            if (mysqli_stmt_prepare($stmt, $sql)) {
                mysqli_stmt_bind_param($stmt, "sss", $username, $email, $password);
                if (mysqli_stmt_execute($stmt)) {
                    echo "<div class='alert alert-success'>You are registered successfully.</div>";
                } else {
                    echo "<div class='alert alert-danger'>Registration failed.</div>";
                }
            } else {
                echo "<div class='alert alert-danger'>Database error.</div>";
            }
        } else {
            foreach ($errors as $error) {
                echo "<div class='alert alert-danger'>$error</div>";
            }
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <title>Signup Page</title>
    <style>
        *{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}
*:focus{
    outline: none;
}

body{
    background: rgb(97,147,212);
    position: relative;
    width: 100%;
    min-height: 100vh;
    height: auto;
    display: flex;
    

}
.form{
    margin: 50px;
    width: 400px;
    border-radius: 15px;
    height: 550px;
    color: black;
    background-color: rgba(107, 156, 235);
    
}
.logo{
    width: 200px;
    margin: 20px 0 0 15px ;
    display: block;
    margin-left: auto;
    margin-right: auto;
    justify-content: center;
    cursor: pointer;
    display: block;
}
input ,.login-btn{
    width: 80%;
    height: 35px;
    display: block;
    border: none;
    margin: 20px auto;
    border-radius: 5px;
    background: rgba(115, 193, 212, 0.3);
    color: black;
    padding: 15px;
    transition: .5s;
    
}
input:focus{
    color: black;
    border: solid 1px;
}
input:focus::placeholder{
    color: black;

}
.login-btn{
    width: 80%;
    cursor: pointer;
    background-color: rgb(26, 26, 93);
    color: white;
    margin: 30px auto 0;
    text-align: center;
    font-weight: 400;
    font-size: large;
    padding: 0 20px;
    transition: .5s;
}
.login-btn:hover{
    background-color: rgb(247, 247, 180);
    color: black;
    border: solid 1px;
}
p{
    text-align: center;
    margin: 20px;
}
p a{
    color: #385898;
    font-size: large;
}
.img{
    width: 400px;
    height: 500px;

}


    </style>

</head>
<body>
    <div class="form">
    <img src="logo2.png" class="logo">
        <form action="register.php"  method="post">
            <div class="form-group">
                <input type="text" class="email" name="username" placeholder="username">
            </div>
            <div class="form-group">
                <input type="email" class="email" name="email" placeholder="email">
            </div>
            <div class="form-group">
                <input type="password" name="password" class="pwd" placeholder="password">
            </div>
            <div class="form-group">
                <input type="text" name="repeat_password" class="pwd" placeholder="Repeat password">
            </div>
            <div class="form-group">
                <input type="submit" value="Register" class="login-btn" name="submit">
            </div>
            <p>------------------Or------------------</p>
        <p class="signup">Already have an account? <br><a href="login.php">login</a> </p>
        </form>
    </div>
    <img src="car2.png" alt="" width="70%">
</body>
</html>