<?php
$conn = mysqli_connect('localhost', 'root', '', 'gravity');
session_start();
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $email =  $_POST['email'];
    $password =  $_POST['password'];

    if (!empty($email) && !empty($password) && !is_numeric($email)) {
        $query = "SELECT * FROM gravity_registrations WHERE email='$email' LIMIT 1";
        $result = mysqli_query($conn, $query);
        if ($result) {
            if ($result && mysqli_num_rows($result) > 0) {
                $user_data = mysqli_fetch_assoc($result);
                if ($user_data['password'] == $password) {
                    echo "<script> alert('Successfully logged in'); window.location.href = 'index.html'; </script>";
                    die;
                }
            }
        }
        echo "<script> alert('Wrong email and password')</script>";
    } else {
        echo "<script> alert('Wrong email and password')</script>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="upload.css">
<link rel="stylesheet" href="home.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<script src="server.js"></script>
<script src="slide.js"></script>

<title>renterr</title>
</style>
</head>
<body>
    <nav>
        <div class="logo">renterr</div>
        <ul>
            <li><a href="#">Home</a></li>
            <li><a href="#">My Cars</a></li>
        </ul>
    
        <div class="user-icon">
            <i class="fa-regular fa-user"></i>
            <button onclick="form1()">Upload</button>
        </div>
    </nav>
<div id="form1" class="container" style="display: none;">
    <!-- <img  src="pngwing.com (1).png" alt=""> -->
    <button class="hide"     onclick="hideForm()"><img src="pngwing.com (1).png" alt=""></button>

    <div class="forms" id="forms">
        <label for="name">Name:</label>
        <input type="text" name="name" id="name" placeholder="Your Name"><br>
        <label for="vechicle">Vehicle number:</label>
        <input type="text" name="vechicle" id="vechicle" placeholder="DL XX XX 1234"><br>
        <label for="vname">Vehicle Name:</label>
        <input type="text" name="vname" id="vname" placeholder="Maruti Alto"><br>
        <label for="carInsurance">Car Insurance:</label><br>
        <input class="files" type="file" name="carInsurance" id="carInsurance"><br>
        <label for="image1">Car Image:</label><br>
        <input class="files" type="file" name="image1" id="image1" required>
        <input class="files" type="file" name="image2" id="image2" required><br>
        <button>Upload</button>
    </div>
</div>

</body>
</html>