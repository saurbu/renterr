<?php
       $conn = mysqli_connect('localhost', 'root', '', 'login');
       session_start();
       if ($_SERVER['REQUEST_METHOD'] == "POST") {
           $email =  $_POST['email'];
           $password =  $_POST['password'];
       
           if (!empty($email) && !empty($password) && !is_numeric($email)) {
               $query = "SELECT * FROM login4 WHERE email='$email' LIMIT 1";
               $result = mysqli_query($conn, $query);
               if ($result) {
                   if ($result && mysqli_num_rows($result) > 0) {
                       $user_data = mysqli_fetch_assoc($result);
                       if ($user_data['password'] == $password) {
                           echo "<script> alert('Successfully logged in'); window.location.href = 'home1.html'; </script>";
                           die;
                       }
                   }
               }
               echo "<script> alert('Wrong email and password')</script>";
           } else {
               echo "<script> alert('Wrong email and password')</script>";
           }
       }
       
        ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>login</title>
    <style>
                *{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}
*:focus{
    outline: none;
}

body{
    background: rgb(97,147,212);
    position: relative;
    width: 100%;
    min-height: 100vh;
    height: auto;
    display: flex;
    

}
.form{
    margin: 50px;
    width: 400px;
    border-radius: 15px;
    height: 550px;
    color: black;
    background-color: rgba(107, 156, 235);
}
.logo{
    width: 200px;
    margin: 20px 0 0 15px ;
    display: block;
    margin-left: auto;
    margin-right: auto;
    justify-content: center;
    cursor: pointer;
    display: block;
}
input ,.login-btn{
    width: 80%;
    height: 35px;
    display: block;
    border: none;
    margin: 20px auto;
    border-radius: 5px;
    background: rgba(115, 193, 212, 0.3);
    color: black;
    padding: 15px;
    transition: .5s;
    
}
input:focus{
    color: black;
    border: solid 1px;
}
input:focus::placeholder{
    color: black;

}
.login-btn{
    width: 80%;
    cursor: pointer;
    background-color: rgb(26, 26, 93);
    color: white;
    margin: 30px auto 0;
    text-align: center;
    font-weight: 400;
    font-size: large;
    padding: 0 20px;
    transition: .5s;
}
.login-btn:hover{
    background-color: rgb(247, 247, 180);
    color: black;
    border: solid 1px;
}
p{
    text-align: center;
    margin: 20px;
}
p a{
    color: #385898;
    font-size: large;
}
.img{
    width: 400px;
    height: 500px;

}

    </style>
</head>

<body>
    <div class="form">
        <img src="logo2.png" class="logo">
        

        <form action="login.php" class="forrm" method="post">
            <div class="form-group">
                <input type="email" class="uname" placeholder="email" name="email" >
            </div>
            <div class="form-group">
            <input type="password" class="pwd" name="password" placeholder="password">
            </div>
            <div class="form-btn">
                <a href="index.html"><input type="submit" class="login-btn" value="login" name="login" ></a>
            </div>

            <p>------------------Or------------------</p>
        <p class="signup">don't have an account? <br><a href="register.php">sign up</a> </p> 
    </div>
    <img src="car2.png" alt="" width="70%" >

</body>
</html>