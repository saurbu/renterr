const express = require('express');
const multer = require('multer');
const path = require('path');
const cors = require('cors');
const mongoose = require('mongoose');

const app = express();
const port = 3000;
const dbKey = "mongodb+srv://ss0619963:ZEOCrCrdr1uzYPNx@majorproject.ci18ngy.mongodb.net/?retryWrites=true&w=majority&appName=majorproject";
// const dbKey = 'mongodb+srv://csekaran arora:karan_code@cluster0.oiok9eo.mongodb.net/te?retryWrites=true&w=majority&appName=Cluster0'

mongoose.connect(dbKey);
mongoose.connection.on('error', err => console.log("unable to connect"));
mongoose.connection.on('connected', err => console.log("connected to MongoDB"));


const Schema = mongoose.Schema;
const carServiceSchema = new Schema({
  make: String,
  model: String,
  year: Number,
  price: Number,
  carImage: String
});
const carServiceModel = mongoose.model('YourModel', carServiceSchema);

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/')
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname)
  }
});

const upload = multer({ storage: storage });

app.use(cors());
app.use(express.json());
app.use('/img', express.static(path.join(__dirname, 'uploads')));
// app.use((err, req, res, next) => {
//   if (err instanceof multer.MulterError) {
//     // Multer error handling
//     console.error('Multer error:', err);
//     res.status(400).json({ error: 'File upload failed' });
//   } else {
//     next(err);
//   }
// });


// Endpoint for handling form submission with image upload

app.post('/submit', upload.single('carImage'), (req, res) => {
  console.log('Uploaded file:', req.file);
  console.log('Form data:', req.body);
  let { make, model, year, price } = req.body;

  let newData = {
    make: make,
    model: model,
    year: year,
    price: price,
    carImage: req.file.filename
  }

  let newService = new carServiceModel(newData);
  console.log(newService);
  newService.save();
  res.json({ message: 'Form submitted successfully' });
});

app.get('/allCarService',(req,res)=>{
  carServiceModel.find()
 .then(result=>{
  console.log(result);
  res.json(result);
 });
})


const carSchema = new Schema({
  insurenceNumber: String,
  vehicleNumber: String,
  vechicleName: String,
  name: String,
  carImage: String
});
const carModel = mongoose.model('car', carSchema);

app.post('/registerCar',upload.single('carImage') , (req,res)=>{
  let { name, insurenceNumber, vehicleNumber, vechicleName } = req.body;
  // carImage
  // insurenceNumber
  // vehicleNumber
  // vechicleName
  // name
  let newCarData = {
    insurenceNumber: insurenceNumber,
    vehicleNumber: vehicleNumber,
    vechicleName: vechicleName,
    name: name,
    carImage: req.file.filename
  }

  let newCar = new carModel(newCarData);
  console.log(newCar);
  newCar.save();
  res.json({ message: 'Form submitted successfully' });
})
app.get('/getCars',(req, res) => {
  carModel.find()
  .then(result=>{
   console.log(result);
   res.json(result);
  });
})







app.get('/tmp', (req, res) => {
  const newData = new YourModel({
    name: 'John',
    age: 30,
    email: 'john@example.com'
  });

  newData.save()
    .then(result => {
      console.log('Data saved successfully:', result);
      res.json({ msg: "saved" });
    })
    .catch(error => {
      console.error('Error saving data:', error);
      res.json({ error: "error" });
    });
})

app.get('/tmpdata', (req, res) => {
  console.log("first")
  YourModel.find()
    .then(result => {
      console.log('Data retrieved successfully:', result);
      res.json(result);
    })
    .catch(error => {
      console.error('Error retrieving data:', error);
      res.json({ error: "error" });
    });
})

app.listen(port, () => {
  console.log(`Server is listening at http://localhost:${port}`);
});


// const express = require('express');
// const cors = require('cors');
// const multer = require('multer');
// const path = require('path');

// const app = express();
// const port = 3000;

// const storage = multer.diskStorage({
//   destination: function(req, file, cb) {
//     cb(null, 'uploads/');
//   },
//   filename: function(req, file, cb) {
//     cb(null, file.originalname);
//   }
// });

// const upload = multer({ storage: storage });

// app.use(cors());
// app.use(express.json());

// app.post('/submit', upload.single('carImage'), (req, res) => {
//   console.log('Received data:', req.body);
//   console.log('Received file:', req.file);
//   res.json({ message: 'Data received successfully' });
// });

// app.listen(port, () => {
//   console.log(`Server is listening at http://localhost:${port}`);
// });
