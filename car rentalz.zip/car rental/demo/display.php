<!DOCTYPE html>
<html>
<head>
    <title>Form Input</title>
</head>
<body>

<h2>Enter Your Information</h2>

<form action="display.php" method="post">
    <label for="name">Name:</label><br>
    <input type="text" id="name" name="name"><br>
    
    <label for="email">Email:</label><br>
    <input type="email" id="email" name="email"><br>
    
    <input type="submit" value="Submit">
</form>

<?php
// Step 1: Establish a database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "display";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Step 2: Prepare SQL statement
$sql = "INSERT INTO display (name, email) VALUES (?, ?)";

// Step 3: Execute SQL statement
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $name, $email);

    if ($stmt->execute()) {
        echo "Data inserted successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $stmt->close();
}

// Step 4: Close connection
$conn->close();
?>

</body>
</html>
