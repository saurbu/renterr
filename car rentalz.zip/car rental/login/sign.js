// Generate random 6-digit OTP
function generateOTP() {
    return Math.floor(100000 + Math.random() * 900000);
}

function validateMobileNumber(mobile) {
    return /^\d{10}$/.test(mobile);
}

function sendOTP() {
    const mobileNumber = document.getElementById('mobile').value;

    if (!validateMobileNumber(mobileNumber)) {
        document.getElementById('mobile-error').textContent = 'Please enter a valid 10-digit number.';
        return;
    } else {
        document.getElementById('mobile-error').textContent = '';
    }

    const otp = generateOTP();

    localStorage.setItem('otp', otp);

    const enteredOTP = alert(`An OTP has been sent to ${mobileNumber}. Your OTP is: ${otp}. Please enter the OTP:`);

    document.getElementById('otp-container').style.display = 'block';

    if (enteredOTP) {
        document.getElementById('otp').value = enteredOTP;
    }
}

document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const enteredOTP = document.getElementById('otp').value;
    const storedOTP = localStorage.getItem('otp');

    if (enteredOTP === storedOTP) {
        window.location.href = 'home.html';
    } else {
        alert('Incorrect OTP. Please try again.');
    }
});
