from flask import Flask, render_template, request
from pymongo import MongoClient
from bson.binary import Binary
import os

app = Flask(__name__)
client = MongoClient('mongodb://localhost:27017/')
db = client['my_database']
collection = db['images']

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    if 'image' in request.files:
        image_file = request.files['image']
        if image_file.filename != '':
            image_data = image_file.read()
            image_content_type = image_file.content_type
            image_binary = Binary(image_data)
            collection.insert_one({'image': image_binary, 'content_type': image_content_type})
            return 'Image uploaded successfully'
    return 'No image selected for upload'

if __name__ == '__main__':
    app.run(debug=True)
