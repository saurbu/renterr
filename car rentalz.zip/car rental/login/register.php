<?php

if (isset($_POST["submit"])) {
    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $passwordRepeat = $_POST["repeat_password"];

    // Validation
    $errors = array();
    if (empty($username) || empty($email) || empty($password) || empty($passwordRepeat)) {
        $errors[] = "All fields are required.";
    } elseif ($password !== $passwordRepeat) {
        $errors[] = "Passwords do not match.";
    } else {
        // Password hashing
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);

        require_once "database.php";

        // Check if user exists
        $sql = "SELECT * FROM login3 WHERE email=?";
        $stmt = mysqli_stmt_init($conn);
        if (mysqli_stmt_prepare($stmt, $sql)) {
            mysqli_stmt_bind_param($stmt, "s", $email);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_store_result($stmt);
            if (mysqli_stmt_num_rows($stmt) > 0) {
                $errors[] = "User already exists with this email.";
            }
        } else {
            $errors[] = "Database error.";
        }

        // If no errors, insert new user
        if (empty($errors)) {
            $sql = "INSERT INTO login3 (username, email, password) VALUES (?, ?, ?)";
            $stmt = mysqli_stmt_init($conn);
            if (mysqli_stmt_prepare($stmt, $sql)) {
                mysqli_stmt_bind_param($stmt, "sss", $username, $email, $passwordHash);
                if (mysqli_stmt_execute($stmt)) {
                    echo "<div class='alert alert-success'>You are registered successfully.</div>";
                } else {
                    echo "<div class='alert alert-danger'>Registration failed.</div>";
                }
            } else {
                echo "<div class='alert alert-danger'>Database error.</div>";
            }
        } else {
            foreach ($errors as $error) {
                echo "<div class='alert alert-danger'>$error</div>";
            }
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Signup Page</title>
    <style>
        body{
            background: rgba(107, 156, 235, 0.5);
            display: flex;
        }
        .form{
            height: 550px;
            background-color: rgba(107, 156, 235);
        }
    </style>

</head>
<body>
    <div class="form">
    <img src="logo2.png" class="logo">
        <form action="register.php"  method="post">
            <div class="form-group">
                <input type="text" class="email" name="username" placeholder="username">
            </div>
            <div class="form-group">
                <input type="email" class="email" name="email" placeholder="email">
            </div>
            <div class="form-group">
                <input type="password" name="password" class="pwd" placeholder="password">
            </div>
            <div class="form-group">
                <input type="text" name="repeat_password" class="pwd" placeholder="Repeat password">
            </div>
            <div class="form-group">
                <input type="submit" value="Register" class="login-btn" name="submit">
            </div>
            <p>------------------Or------------------</p>
        <p class="signup">Already have an account? <br><a href="login.php">login</a> </p>
        </form>
    </div>
    <img src="car2.png" alt="" width="70%">
</body>
</html>